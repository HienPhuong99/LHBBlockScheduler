;;; ==========================================================================
;;; LHB.lsp - Auto-loader cho tiện ích LHBBlockScheduler (AutoCAD Add-in)
;;; Tự động xác định đường dẫn DLL, chống nạp trùng lặp, hỗ trợ kéo thả & APPLOAD
;;; ==========================================================================

(vl-load-com)

(defun c:LHBHELP ()
  (princ "\n==================================================================")
  (princ "\n  LHBBlockScheduler - DANH SÁCH LỆNH KHẢ DỤNG:")
  (princ "\n  - LHBSCAN       : Mở giao diện Thống kê Block đầy đủ tính năng")
  (princ "\n  - LHBSCANTEST   : Quét nhanh block và in kết quả ra Command Line")
  (princ "\n  - LHBTHUMBTEST  : Kiểm tra xuất ảnh đại diện (thumbnail) của block")
  (princ "\n  - LHBLEGEND     : Quét bảng Legend (Table) có sẵn vào Thư viện")
  (princ "\n  - LHBCLEARCACHE : Xoá bộ nhớ đệm hình ảnh thumbnail")
  (princ "\n  - LHBLOG        : Mở file nhật ký ghi lỗi (log.txt)")
  (princ "\n  - LHBLOGPATH    : In đường dẫn tuyệt đối của file log (log.txt)")
  (princ "\n  - LHBDIAG       : Thu thập toàn bộ thông tin chẩn đoán hệ thống ra file text")
  (princ "\n  - LHBRELOAD     : Nạp bản cập nhật mới nhất từ thư mục Runtime (Dev)")
  (princ "\n  - LHBVERSION    : Xem thông tin phiên bản, cấu hình, build time, MD5")
  (princ "\n==================================================================\n")
  (princ)
)

(defun lhb:LoadPlugin ( / lhbFile lhbDir lhbDll lhbLoaderDll targetDll)
  (if (not *LHB_PLUGIN_LOADED*)
    (progn
      (setq lhbFile (findfile "LHB.lsp"))
      (if (and lhbFile (/= lhbFile ""))
        (progn
          (setq lhbDir (vl-filename-directory lhbFile))
          (setq lhbDll (strcat lhbDir "\\LHBBlockScheduler.dll"))
          (setq lhbLoaderDll (strcat lhbDir "\\LHBLoader.dll"))
          
          ;; Ưu tiên LHBLoader.dll (shadow-copy chống lock file), nếu không có mới nạp LHBBlockScheduler.dll
          (cond
            ((findfile lhbLoaderDll)
             (setq targetDll lhbLoaderDll))
            ((findfile lhbDll)
             (setq targetDll lhbDll))
            (t (setq targetDll nil))
          )

          (if targetDll
            (progn
              (setvar "CMDECHO" 0)
              (vl-cmdf "_.NETLOAD" targetDll)
              (setvar "CMDECHO" 1)
              (setq *LHB_PLUGIN_LOADED* T)
              (princ "\n[LHB] Đã nạp thành công tiện ích LHBBlockScheduler!")
              (c:LHBHELP)
            )
            (princ (strcat "\n[LHB LỖI] Không tìm thấy file DLL tại thư mục: " lhbDir "\n"))
          )
        )
        (princ "\n[LHB LỖI] Không thể xác định vị trí file LHB.lsp!\n")
      )
    )
    (progn
      (princ "\n[LHB] Tiện ích LHBBlockScheduler đã được nạp trước đó.")
      (princ "\nGõ LHBSCAN để mở bảng thống kê, hoặc LHBHELP để xem trợ giúp.\n")
    )
  )
  (princ)
)

;; Tự động chạy khi file LISP được nạp
(lhb:LoadPlugin)
