;;; ==========================================================================
;;; LHB.lsp - Auto-loader cho tiện ích LHBBlockScheduler (AutoCAD Add-in)
;;; Tìm thư mục chứa LHBBlockScheduler.dll theo thứ tự:
;;;   1. (findfile "LHB.lsp") - khi thư mục add-in nằm trong Support File Search Path
;;;   2. Thư mục đã nhớ trong registry HKCU\Software\LHBBlockScheduler\InstallDir
;;;      (DLL tự ghi mỗi lần được nạp, LISP ghi khi người dùng chọn tay)
;;;   3. Hộp thoại chọn file LHBBlockScheduler.dll (chỉ cần làm 1 lần, sau đó tự nhớ)
;;; Lý do: kéo thả / APPLOAD không cho LISP biết đường dẫn của chính nó, findfile chỉ tìm
;;; trong Support Path -> lỗi "Không thể xác định vị trí file LHB.lsp!" (test 28/09/2026).
;;; KHÔNG nạp LHBLoader.dll: loader chỉ dùng trên máy build (đọc %APPDATA%\...\Runtime).
;;; ==========================================================================

(vl-load-com)

(setq *LHB_REG_KEY* "HKEY_CURRENT_USER\\Software\\LHBBlockScheduler")

(defun c:LHBHELP ()
  (princ "\n==================================================================")
  (princ "\n  LHBBlockScheduler - DANH SÁCH LỆNH KHẢ DỤNG:")
  (princ "\n  - LHBSCAN       : Mở giao diện Thống kê Block đầy đủ tính năng")
  (princ "\n  - LHBSCANTEST   : Quét nhanh block và in kết quả ra Command Line")
  (princ "\n  - LHBTHUMBTEST  : Kiểm tra xuất ảnh đại diện (thumbnail) của block")
  (princ "\n  - LHBLEGEND     : Quét bảng Legend (Table) có sẵn vào Thư viện")
  (princ "\n  - LHBCLEARCACHE : Xoá bộ nhớ đệm hình ảnh thumbnail")
  (princ "\n  - LHBLOG        : Mở file nhật ký ghi lỗi (log.txt)")
  (princ "\n  - LHBLOGPATH    : In đường dẫn tuyệt đối của file log (log.txt)")
  (princ "\n  - LHBDIAG       : Thu thập toàn bộ thông tin chẩn đoán hệ thống ra file text")
  (princ "\n  - LHBVERSION    : Xem thông tin phiên bản, cấu hình, build time, MD5")
  (princ "\n  - LHBSETPATH    : Chọn lại thư mục chứa LHBBlockScheduler.dll")
  (princ "\n==================================================================\n")
  (princ)
)

;; Trả về thư mục (không có "\" cuối) nếu trong đó có LHBBlockScheduler.dll, ngược lại nil
(defun lhb:ValidDir (dir)
  (if (and dir (/= dir "") (findfile (strcat dir "\\LHBBlockScheduler.dll")))
    dir
  )
)

;; Hộp thoại chọn DLL, nhớ thư mục vào registry
(defun lhb:AskDir ( / lastDir picked)
  (setq lastDir (vl-registry-read *LHB_REG_KEY* "InstallDir"))
  (setq picked
    (getfiled "Chọn file LHBBlockScheduler.dll (chỉ cần chọn 1 lần)"
              (if (lhb:ValidDir lastDir) (strcat lastDir "\\") "")
              "dll" 0))
  (if picked
    (progn
      (vl-registry-write *LHB_REG_KEY* "InstallDir" (vl-filename-directory picked))
      (lhb:ValidDir (vl-filename-directory picked))
    )
  )
)

(defun lhb:FindDir ( / lspFile dir)
  (cond
    ;; 1. Support Path
    ((and (setq lspFile (findfile "LHB.lsp"))
          (setq dir (lhb:ValidDir (vl-filename-directory lspFile))))
     (princ (strcat "\n[LHB] Tìm thấy add-in qua Support Path: " dir))
     dir)
    ;; 2. Registry
    ((setq dir (lhb:ValidDir (vl-registry-read *LHB_REG_KEY* "InstallDir")))
     (princ (strcat "\n[LHB] Dùng thư mục đã nhớ: " dir))
     (princ "\n[LHB] Nếu sai thư mục (vd còn bản cũ), gõ LHBSETPATH để chọn lại.")
     dir)
    ;; 3. Hỏi người dùng
    (t
     (princ "\n[LHB] Chưa biết thư mục add-in -> hãy chọn file LHBBlockScheduler.dll...")
     (lhb:AskDir))
  )
)

(defun lhb:NetloadDir (dir / dll)
  (setq dll (strcat dir "\\LHBBlockScheduler.dll"))
  (setvar "CMDECHO" 0)
  (vl-cmdf "_.NETLOAD" dll)
  (setvar "CMDECHO" 1)
  (setq *LHB_PLUGIN_LOADED* T)
  (princ (strcat "\n[LHB] Đã nạp: " dll))
  (princ "\n[LHB] Gõ LHBVERSION để kiểm tra MD5 phiên bản.")
  (c:LHBHELP)
)

(defun lhb:LoadPlugin ( / dir)
  (if (not *LHB_PLUGIN_LOADED*)
    (if (setq dir (lhb:FindDir))
      (lhb:NetloadDir dir)
      (princ "\n[LHB LỖI] Không xác định được thư mục chứa LHBBlockScheduler.dll. Kéo thả lại LHB.lsp hoặc gõ LHBSETPATH.\n")
    )
    (progn
      (princ "\n[LHB] Tiện ích LHBBlockScheduler đã được nạp trước đó.")
      (princ "\nGõ LHBSCAN để mở bảng thống kê, hoặc LHBHELP để xem trợ giúp.\n")
    )
  )
  (princ)
)

;; Chọn lại thư mục DLL. Lưu ý: AutoCAD không gỡ được DLL .NET đã nạp,
;; muốn dùng bản khác phải tắt/mở lại AutoCAD rồi kéo thả LHB.lsp.
(defun c:LHBSETPATH ( / dir)
  (if (setq dir (lhb:AskDir))
    (progn
      (princ (strcat "\n[LHB] Đã nhớ thư mục: " dir))
      (if *LHB_PLUGIN_LOADED*
        (princ "\n[LHB] Add-in đã nạp trong phiên này. Tắt và mở lại AutoCAD để dùng bản ở thư mục mới.")
        (lhb:NetloadDir dir)
      )
    )
    (princ "\n[LHB] Đã huỷ chọn thư mục.")
  )
  (princ)
)

;; Tự động chạy khi file LISP được nạp
(lhb:LoadPlugin)
